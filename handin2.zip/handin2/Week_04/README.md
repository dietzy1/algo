To run the code:
1. Install Python v3.8 or higher
2. Follow the instructions to install Jupyter Notebook: https://jupyter.org/install#jupyter-notebook
3. Run notebook: `jupyter notebook`
4. Open and run all cells of the .pynb file.
5. If packages are missing, install them: `pip install missing-package-name`